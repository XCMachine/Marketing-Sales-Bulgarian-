﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Продажби
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
        }

        private void treeView1_DoubleClick(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(treeView1, "За да изберете артикул, кликнете 2 пъти върху него!");
            this.Close();
        }
    }
}
