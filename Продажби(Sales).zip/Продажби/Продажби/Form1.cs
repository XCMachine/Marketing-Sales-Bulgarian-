﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Продажби
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public double Total(double price, double numbers)
        {
            return price * numbers;
        }

        public double AmountTotal(double price, double quantity) 
        {
            return price * quantity;
        }

        private void exitButton_Click(object sender, EventArgs e) // бутон Изход
        {
            DialogResult result = MessageBox.Show("Апликацията ще изгуби всички данни, сигурни ли сте че искате да излизате от апликацията ?", "", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {

            }
        }

        private void neworderButton_Click(object sender, EventArgs e) // бутон Нова продажба
        {
            discountText.ReadOnly = true;
            amountText.ReadOnly = true;
            itemComboBox.Enabled = true;

            
            unitPriceText.Clear();
            quantityText.Clear();
            discountText.Clear();
            amountText.Clear();

            calcButton.Enabled = true;
            neworderButton.Enabled = false;
            unitPriceText.ReadOnly = false;
            quantityText.ReadOnly = false;

        }

        double grandDisc = 0; // отчет отстъпка
        double grandTotal = 0; // отчет стойност
        double grandDiscount = 0; // брой продажби

        double valueInLevReport = 0; // отчет отстъпка в лев
        double discountInLevReport = 0; // отчет стойност в лев
        double totalInLevReport = 0; // брой продажби в лев

        private void calcButton_Click(object sender, EventArgs e) // бутон Калкулиране
        {
            try
            {
                if (unitPriceText.Text == "")
                {
                    throw new MyRequiredFieldException("Ед.цена");
                }
                else if (Convert.ToInt32(unitPriceText.Text) < 0)
                {
                    MessageBox.Show("Моля, попълнете Положителна стойност в поле ед.цена!");
                    return;
                }

                if (quantityText.Text == "")
                {
                    throw new MyRequiredFieldException("Количество");
                }
                else if (Convert.ToInt32(quantityText.Text) < 0)
                {
                    MessageBox.Show("Моля, попълнете количеството в поле Количество!");
                    return;
                }

                if (itemComboBox.Items == null)
                {
                    MessageBox.Show("Моля, попълнете артикула в поле Артикули!");
                    throw new MyRequiredFieldException("Артикул");
                }
            }
            catch (System.FormatException) // обработка при грешка във формата
            {
                //ако е въведено нещо разлицхно от число
                MessageBox.Show("Моля, въведете валидно число в поле ед.цена!");
            }
            catch (MyRequiredFieldException ee) //обработка при нашата грешка
            {
                MessageBox.Show(string.Format("Моля, попълнете стойност в поле {0} !", ee.Message));
            }

            double tAmount = AmountTotal(Convert.ToInt32(unitPriceText.Text), Convert.ToInt32(quantityText.Text));
            double total = Total(Convert.ToDouble(unitPriceText.Text), Convert.ToDouble(quantityText.Text));
            double discount = 0;
            amountText.Text = tAmount.ToString();
            discountText.Text = discount.ToString();
            if (total > 100)
            {
                discount = 0.10 * total;
                discountText.ForeColor = Color.Red;
            }
            else 
            {
                discount = 0;
                discountText.ForeColor = Color.Black;
            }
            total -= discount;// total = total - discount;
            

            calcButton.Enabled = false;
            neworderButton.Enabled = true;

            grandDiscount += discount; //grandDiscount = grandDiscount + discount;
            calcButton.Enabled = false;

            string[] row = { Convert.ToString(dateTimePicker1.Value),
                itemComboBox.Text, unitPriceText.Text, quantityText.Text, discountText.Text, amountText.Text };
            ListViewItem it = new ListViewItem(row);
            lvItems.Items.Add(it);
        }

        private void finalizeButton_Click(object sender, EventArgs e) // бутон Приключване
        {
            grandTotalText.Text = grandTotal.ToString();
            grandDiscountText.Text = grandDisc.ToString();
            grandStorageText.Text = amountText.ToString();

            valueInLevText.Text = valueInLevReport.ToString();
            discountInLevText.Text = discountInLevReport.ToString();
            totalInLevText.Text = totalInLevReport.ToString();

            neworderButton.Enabled = true;
            calcButton.Enabled = false;
            itemComboBox.Enabled = false;
            unitPriceText.ReadOnly = true;
            quantityText.ReadOnly = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] items = { "Артикул 1", "Артикул 2", "Артикул 3" };
            itemComboBox.DataSource = items;
            itemComboBox.SelectedIndex = -1;
        }

        class MyRequiredFieldException : Exception 
        {
            public MyRequiredFieldException(string message) : base(message) 
            {
                
            }
        }
    }
}
