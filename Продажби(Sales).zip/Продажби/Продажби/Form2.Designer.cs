﻿namespace Продажби
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.newOrderTS = new System.Windows.Forms.ToolStripMenuItem();
            this.новаПродажбаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.списъкПродажбиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.номенклатуриToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.продуктиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorDialogTS = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.totalInLevText = new System.Windows.Forms.TextBox();
            this.discountInLevText = new System.Windows.Forms.TextBox();
            this.storageInLevText = new System.Windows.Forms.TextBox();
            this.grandDiscountText = new System.Windows.Forms.TextBox();
            this.grandTotalText = new System.Windows.Forms.TextBox();
            this.grandStorageText = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.valueComboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_Client = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.stockGridView = new System.Windows.Forms.DataGridView();
            this.itemsGridCB = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.priceGridTB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityGridTB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discountGridTB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalGridTB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.newOrderTS,
            this.справкиToolStripMenuItem,
            this.номенклатуриToolStripMenuItem,
            this.настройкиToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(722, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripBtn});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // exitToolStripBtn
            // 
            this.exitToolStripBtn.Name = "exitToolStripBtn";
            this.exitToolStripBtn.ShortcutKeys = System.Windows.Forms.Keys.F10;
            this.exitToolStripBtn.Size = new System.Drawing.Size(132, 22);
            this.exitToolStripBtn.Text = "Изход";
            this.exitToolStripBtn.Click += new System.EventHandler(this.exitToolStripBtn_Click);
            // 
            // newOrderTS
            // 
            this.newOrderTS.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.новаПродажбаToolStripMenuItem});
            this.newOrderTS.Name = "newOrderTS";
            this.newOrderTS.Size = new System.Drawing.Size(77, 20);
            this.newOrderTS.Text = "Продажби";
            // 
            // новаПродажбаToolStripMenuItem
            // 
            this.новаПродажбаToolStripMenuItem.Name = "новаПродажбаToolStripMenuItem";
            this.новаПродажбаToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.новаПродажбаToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.новаПродажбаToolStripMenuItem.Text = "Нова Продажба";
            this.новаПродажбаToolStripMenuItem.Click += new System.EventHandler(this.новаПродажбаToolStripMenuItem_Click);
            // 
            // справкиToolStripMenuItem
            // 
            this.справкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.списъкПродажбиToolStripMenuItem});
            this.справкиToolStripMenuItem.Name = "справкиToolStripMenuItem";
            this.справкиToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.справкиToolStripMenuItem.Text = "Справки";
            // 
            // списъкПродажбиToolStripMenuItem
            // 
            this.списъкПродажбиToolStripMenuItem.Name = "списъкПродажбиToolStripMenuItem";
            this.списъкПродажбиToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Q)));
            this.списъкПродажбиToolStripMenuItem.Size = new System.Drawing.Size(217, 22);
            this.списъкПродажбиToolStripMenuItem.Text = "Списък продажби";
            this.списъкПродажбиToolStripMenuItem.Click += new System.EventHandler(this.списъкПродажбиToolStripMenuItem_Click);
            // 
            // номенклатуриToolStripMenuItem
            // 
            this.номенклатуриToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.продуктиToolStripMenuItem});
            this.номенклатуриToolStripMenuItem.Name = "номенклатуриToolStripMenuItem";
            this.номенклатуриToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.номенклатуриToolStripMenuItem.Text = "Номенклатури";
            // 
            // продуктиToolStripMenuItem
            // 
            this.продуктиToolStripMenuItem.Name = "продуктиToolStripMenuItem";
            this.продуктиToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Space)));
            this.продуктиToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.продуктиToolStripMenuItem.Text = "Продукти";
            this.продуктиToolStripMenuItem.Click += new System.EventHandler(this.продуктиToolStripMenuItem_Click);
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.colorDialogTS});
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.настройкиToolStripMenuItem.Text = "Настройки";
            // 
            // colorDialogTS
            // 
            this.colorDialogTS.Name = "colorDialogTS";
            this.colorDialogTS.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
            this.colorDialogTS.Size = new System.Drawing.Size(191, 22);
            this.colorDialogTS.Text = "Смяна на цвят";
            this.colorDialogTS.Click += new System.EventHandler(this.colorDialogTS_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(667, 310);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.valueComboBox);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.txt_Client);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(659, 284);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Основни данни";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.totalInLevText);
            this.groupBox1.Controls.Add(this.discountInLevText);
            this.groupBox1.Controls.Add(this.storageInLevText);
            this.groupBox1.Controls.Add(this.grandDiscountText);
            this.groupBox1.Controls.Add(this.grandTotalText);
            this.groupBox1.Controls.Add(this.grandStorageText);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(57, 129);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(544, 121);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Отчет";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(408, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "лв.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(408, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "...";
            // 
            // totalInLevText
            // 
            this.totalInLevText.Location = new System.Drawing.Point(302, 73);
            this.totalInLevText.Name = "totalInLevText";
            this.totalInLevText.Size = new System.Drawing.Size(100, 20);
            this.totalInLevText.TabIndex = 19;
            // 
            // discountInLevText
            // 
            this.discountInLevText.Location = new System.Drawing.Point(159, 73);
            this.discountInLevText.Name = "discountInLevText";
            this.discountInLevText.Size = new System.Drawing.Size(100, 20);
            this.discountInLevText.TabIndex = 18;
            // 
            // storageInLevText
            // 
            this.storageInLevText.Location = new System.Drawing.Point(22, 73);
            this.storageInLevText.Name = "storageInLevText";
            this.storageInLevText.Size = new System.Drawing.Size(100, 20);
            this.storageInLevText.TabIndex = 17;
            // 
            // grandDiscountText
            // 
            this.grandDiscountText.Location = new System.Drawing.Point(159, 47);
            this.grandDiscountText.Name = "grandDiscountText";
            this.grandDiscountText.Size = new System.Drawing.Size(100, 20);
            this.grandDiscountText.TabIndex = 15;
            // 
            // grandTotalText
            // 
            this.grandTotalText.Location = new System.Drawing.Point(302, 47);
            this.grandTotalText.Name = "grandTotalText";
            this.grandTotalText.Size = new System.Drawing.Size(100, 20);
            this.grandTotalText.TabIndex = 16;
            // 
            // grandStorageText
            // 
            this.grandStorageText.Location = new System.Drawing.Point(22, 47);
            this.grandStorageText.Name = "grandStorageText";
            this.grandStorageText.Size = new System.Drawing.Size(100, 20);
            this.grandStorageText.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(310, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Обща Стойност";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Брой продажби";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(166, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Обща Отстъпка";
            // 
            // valueComboBox
            // 
            this.valueComboBox.FormattingEnabled = true;
            this.valueComboBox.Location = new System.Drawing.Point(106, 84);
            this.valueComboBox.Name = "valueComboBox";
            this.valueComboBox.Size = new System.Drawing.Size(112, 21);
            this.valueComboBox.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Валута:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(64, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Дата:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(106, 52);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // txt_Client
            // 
            this.txt_Client.Location = new System.Drawing.Point(106, 26);
            this.txt_Client.Name = "txt_Client";
            this.txt_Client.Size = new System.Drawing.Size(345, 20);
            this.txt_Client.TabIndex = 1;
            this.txt_Client.Validating += new System.ComponentModel.CancelEventHandler(this.txt_Client_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Клиент:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.stockGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(659, 284);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Стоки";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // stockGridView
            // 
            this.stockGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stockGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemsGridCB,
            this.priceGridTB,
            this.quantityGridTB,
            this.discountGridTB,
            this.totalGridTB});
            this.stockGridView.Location = new System.Drawing.Point(6, 6);
            this.stockGridView.Name = "stockGridView";
            this.stockGridView.Size = new System.Drawing.Size(680, 363);
            this.stockGridView.TabIndex = 0;
            this.stockGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            // 
            // itemsGridCB
            // 
            this.itemsGridCB.HeaderText = "Продукт";
            this.itemsGridCB.Name = "itemsGridCB";
            // 
            // priceGridTB
            // 
            this.priceGridTB.HeaderText = "Ед.цена";
            this.priceGridTB.Name = "priceGridTB";
            this.priceGridTB.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.priceGridTB.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // quantityGridTB
            // 
            this.quantityGridTB.HeaderText = "Количество";
            this.quantityGridTB.Name = "quantityGridTB";
            this.quantityGridTB.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.quantityGridTB.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // discountGridTB
            // 
            this.discountGridTB.HeaderText = "Отстъпка";
            this.discountGridTB.Name = "discountGridTB";
            this.discountGridTB.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.discountGridTB.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // totalGridTB
            // 
            this.totalGridTB.HeaderText = "Стойност";
            this.totalGridTB.Name = "totalGridTB";
            this.totalGridTB.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.totalGridTB.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 365);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.stockGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripBtn;
        private System.Windows.Forms.ToolStripMenuItem newOrderTS;
        private System.Windows.Forms.ToolStripMenuItem новаПродажбаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem списъкПродажбиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem номенклатуриToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem продуктиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorDialogTS;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txt_Client;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox valueComboBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox totalInLevText;
        private System.Windows.Forms.TextBox discountInLevText;
        private System.Windows.Forms.TextBox storageInLevText;
        private System.Windows.Forms.TextBox grandDiscountText;
        private System.Windows.Forms.TextBox grandTotalText;
        private System.Windows.Forms.TextBox grandStorageText;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView stockGridView;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridViewComboBoxColumn itemsGridCB;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceGridTB;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityGridTB;
        private System.Windows.Forms.DataGridViewTextBoxColumn discountGridTB;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalGridTB;
    }
}