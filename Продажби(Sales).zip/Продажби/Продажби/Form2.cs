﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Продажби
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private List<double> TotalDiscount = new List<double>();
        private List<double> TotalSum = new List<double>();

        private void exitToolStripBtn_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Сигурни ли сте, че желаете да напуснете приложението?", "", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {

            }
        }
        private void colorDialogTS_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog1 = new ColorDialog();
            DialogResult res = colorDialog1.ShowDialog();
            if (res == DialogResult.OK) 
            { 
                this.BackColor = colorDialog1.Color; 
            }
        }

        private void новаПродажбаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            stockGridView.Rows.Clear();
            txt_Client.Text = "";

            totalInLevText.Clear();
            discountInLevText.Clear();
            storageInLevText.Clear();
        }

        private void списъкПродажбиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int currentRow;
            double price;
            double cnt;
            double discount = Convert.ToDouble(stockGridView.CurrentRow.Cells[3].Value);

            currentRow = stockGridView.CurrentRow.Index; //check if all the cells have values
            price = Convert.ToDouble(stockGridView.CurrentRow.Cells[1].Value); // Единична цена
            cnt = Convert.ToDouble(stockGridView.CurrentRow.Cells[2].Value); // Количество

            discount = (0.10 * (price * cnt));
            double total = ((price * cnt) - discount);
            stockGridView.CurrentRow.Cells[3].Value = discount.ToString(); // Отстъпка
            stockGridView.CurrentRow.Cells[4].Value = total.ToString(); // Стойност

            for (int i = 0; i < stockGridView.RowCount - 1; i++)
            {
                TotalDiscount.Add(Convert.ToDouble(stockGridView.Rows[i].Cells[3].Value));// Отстъпка
                TotalSum.Add(Convert.ToDouble(stockGridView.Rows[i].Cells[4].Value));// Стойност
            }
            grandDiscountText.Text = (TotalDiscount.Sum()).ToString(); // Отчет отстъпка
            grandTotalText.Text = (TotalSum.Sum()).ToString(); // Отчет обща стойност
            grandStorageText.Text = (stockGridView.RowCount - 1).ToString(); // Отчет брой продажби

            discountInLevText.Text = stockGridView.CurrentRow.Cells[3].Value.ToString(); // Отчет отстъпка в лв.
            storageInLevText.Text = (stockGridView.RowCount - 1).ToString(); // Отчет брой продажби в лв.
            totalInLevText.Text = stockGridView.CurrentRow.Cells[4].Value.ToString(); // Отчет обща стойност в лв.
        }

        ErrorProvider errorProvider1 = new ErrorProvider();
        private void txt_Client_Validating(object sender, CancelEventArgs e) 
        {
            if (txt_Client.Text == "")
            {
                errorProvider1.SetError(txt_Client, "Полето е задължително!");
            }
            else 
            {
                errorProvider1.SetError(txt_Client, "");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string[] items = { "Артикул 1", "Артикул 2", "Артикул 3" };
            itemsGridCB.DataSource = items; // Артикул
        }

        private void продуктиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Products products = new Products();
            products.Show();
        }
    }
}
