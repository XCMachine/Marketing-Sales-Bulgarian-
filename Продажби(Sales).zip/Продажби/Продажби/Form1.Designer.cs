﻿namespace Продажби
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.unitPriceText = new System.Windows.Forms.TextBox();
            this.quantityText = new System.Windows.Forms.TextBox();
            this.discountText = new System.Windows.Forms.TextBox();
            this.amountText = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.totalInLevText = new System.Windows.Forms.TextBox();
            this.discountInLevText = new System.Windows.Forms.TextBox();
            this.valueInLevText = new System.Windows.Forms.TextBox();
            this.grandDiscountText = new System.Windows.Forms.TextBox();
            this.grandTotalText = new System.Windows.Forms.TextBox();
            this.grandStorageText = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.neworderButton = new System.Windows.Forms.Button();
            this.calcButton = new System.Windows.Forms.Button();
            this.finalizeButton = new System.Windows.Forms.Button();
            this.itemComboBox = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lvItems = new System.Windows.Forms.ListView();
            this.Дата = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Артикул = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ЕдЦена = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Качество = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Отстъпка = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Стойност = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.valueComboBox = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Артикул";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ед. цена";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Количество";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Отстъпка";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Стойност";
            // 
            // unitPriceText
            // 
            this.unitPriceText.Location = new System.Drawing.Point(129, 95);
            this.unitPriceText.Name = "unitPriceText";
            this.unitPriceText.Size = new System.Drawing.Size(121, 20);
            this.unitPriceText.TabIndex = 6;
            this.toolTip1.SetToolTip(this.unitPriceText, "Положително число. Задължително!");
            // 
            // quantityText
            // 
            this.quantityText.Location = new System.Drawing.Point(129, 121);
            this.quantityText.Name = "quantityText";
            this.quantityText.Size = new System.Drawing.Size(121, 20);
            this.quantityText.TabIndex = 7;
            this.toolTip1.SetToolTip(this.quantityText, "Положително число. Задължително!");
            // 
            // discountText
            // 
            this.discountText.Location = new System.Drawing.Point(129, 151);
            this.discountText.Name = "discountText";
            this.discountText.Size = new System.Drawing.Size(121, 20);
            this.discountText.TabIndex = 8;
            // 
            // amountText
            // 
            this.amountText.Location = new System.Drawing.Point(129, 178);
            this.amountText.Name = "amountText";
            this.amountText.Size = new System.Drawing.Size(121, 20);
            this.amountText.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.totalInLevText);
            this.groupBox1.Controls.Add(this.discountInLevText);
            this.groupBox1.Controls.Add(this.valueInLevText);
            this.groupBox1.Controls.Add(this.grandDiscountText);
            this.groupBox1.Controls.Add(this.grandTotalText);
            this.groupBox1.Controls.Add(this.grandStorageText);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Location = new System.Drawing.Point(58, 372);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(544, 121);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Отчет";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(408, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "лв.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(408, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(16, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "...";
            // 
            // totalInLevText
            // 
            this.totalInLevText.Location = new System.Drawing.Point(302, 73);
            this.totalInLevText.Name = "totalInLevText";
            this.totalInLevText.Size = new System.Drawing.Size(100, 20);
            this.totalInLevText.TabIndex = 19;
            // 
            // discountInLevText
            // 
            this.discountInLevText.Location = new System.Drawing.Point(159, 73);
            this.discountInLevText.Name = "discountInLevText";
            this.discountInLevText.Size = new System.Drawing.Size(100, 20);
            this.discountInLevText.TabIndex = 18;
            // 
            // valueInLevText
            // 
            this.valueInLevText.Location = new System.Drawing.Point(22, 73);
            this.valueInLevText.Name = "valueInLevText";
            this.valueInLevText.Size = new System.Drawing.Size(100, 20);
            this.valueInLevText.TabIndex = 17;
            // 
            // grandDiscountText
            // 
            this.grandDiscountText.Location = new System.Drawing.Point(159, 47);
            this.grandDiscountText.Name = "grandDiscountText";
            this.grandDiscountText.Size = new System.Drawing.Size(100, 20);
            this.grandDiscountText.TabIndex = 15;
            // 
            // grandTotalText
            // 
            this.grandTotalText.Location = new System.Drawing.Point(302, 47);
            this.grandTotalText.Name = "grandTotalText";
            this.grandTotalText.Size = new System.Drawing.Size(100, 20);
            this.grandTotalText.TabIndex = 16;
            // 
            // grandStorageText
            // 
            this.grandStorageText.Location = new System.Drawing.Point(22, 47);
            this.grandStorageText.Name = "grandStorageText";
            this.grandStorageText.Size = new System.Drawing.Size(100, 20);
            this.grandStorageText.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(310, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Обща Стойност";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 31);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Брой продажби";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(166, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Обща Отстъпка";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(480, 511);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(122, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Изход";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // neworderButton
            // 
            this.neworderButton.Location = new System.Drawing.Point(381, 32);
            this.neworderButton.Name = "neworderButton";
            this.neworderButton.Size = new System.Drawing.Size(122, 23);
            this.neworderButton.TabIndex = 12;
            this.neworderButton.Text = "Нова продажба";
            this.neworderButton.UseVisualStyleBackColor = true;
            this.neworderButton.Click += new System.EventHandler(this.neworderButton_Click);
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(381, 119);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(122, 23);
            this.calcButton.TabIndex = 13;
            this.calcButton.Text = "Калкулиране";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // finalizeButton
            // 
            this.finalizeButton.Location = new System.Drawing.Point(480, 339);
            this.finalizeButton.Name = "finalizeButton";
            this.finalizeButton.Size = new System.Drawing.Size(122, 23);
            this.finalizeButton.TabIndex = 14;
            this.finalizeButton.Text = "Приключване";
            this.finalizeButton.UseVisualStyleBackColor = true;
            this.finalizeButton.Click += new System.EventHandler(this.finalizeButton_Click);
            // 
            // itemComboBox
            // 
            this.itemComboBox.FormattingEnabled = true;
            this.itemComboBox.Location = new System.Drawing.Point(129, 68);
            this.itemComboBox.Name = "itemComboBox";
            this.itemComboBox.Size = new System.Drawing.Size(121, 21);
            this.itemComboBox.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(55, 47);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Дата";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(129, 41);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(157, 20);
            this.dateTimePicker1.TabIndex = 17;
            // 
            // lvItems
            // 
            this.lvItems.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Дата,
            this.Артикул,
            this.ЕдЦена,
            this.Качество,
            this.Отстъпка,
            this.Стойност});
            this.lvItems.HideSelection = false;
            this.lvItems.Location = new System.Drawing.Point(56, 204);
            this.lvItems.Name = "lvItems";
            this.lvItems.Size = new System.Drawing.Size(546, 129);
            this.lvItems.TabIndex = 18;
            this.lvItems.UseCompatibleStateImageBehavior = false;
            this.lvItems.View = System.Windows.Forms.View.Details;
            // 
            // Дата
            // 
            this.Дата.Text = "Дата";
            // 
            // Артикул
            // 
            this.Артикул.Text = "Артикул";
            // 
            // ЕдЦена
            // 
            this.ЕдЦена.Text = "Ед. Цена";
            // 
            // Качество
            // 
            this.Качество.Text = "К-во";
            // 
            // Отстъпка
            // 
            this.Отстъпка.Text = "Отстъпка";
            // 
            // Стойност
            // 
            this.Стойност.Text = "Ст-ст";
            // 
            // valueComboBox
            // 
            this.valueComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.valueComboBox.FormattingEnabled = true;
            this.valueComboBox.Items.AddRange(new object[] {
            "Лев",
            "Долар",
            "Евро"});
            this.valueComboBox.Location = new System.Drawing.Point(256, 95);
            this.valueComboBox.Name = "valueComboBox";
            this.valueComboBox.Size = new System.Drawing.Size(73, 21);
            this.valueComboBox.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 562);
            this.Controls.Add(this.valueComboBox);
            this.Controls.Add(this.lvItems);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.itemComboBox);
            this.Controls.Add(this.finalizeButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.neworderButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.amountText);
            this.Controls.Add(this.discountText);
            this.Controls.Add(this.quantityText);
            this.Controls.Add(this.unitPriceText);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox unitPriceText;
        private System.Windows.Forms.TextBox quantityText;
        private System.Windows.Forms.TextBox discountText;
        private System.Windows.Forms.TextBox amountText;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox grandStorageText;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button neworderButton;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button finalizeButton;
        private System.Windows.Forms.TextBox grandDiscountText;
        private System.Windows.Forms.TextBox grandTotalText;
        private System.Windows.Forms.ComboBox itemComboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ListView lvItems;
        private System.Windows.Forms.TextBox discountInLevText;
        private System.Windows.Forms.TextBox valueInLevText;
        private System.Windows.Forms.ComboBox valueComboBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox totalInLevText;
        private System.Windows.Forms.ColumnHeader Дата;
        private System.Windows.Forms.ColumnHeader Артикул;
        private System.Windows.Forms.ColumnHeader ЕдЦена;
        private System.Windows.Forms.ColumnHeader Качество;
        private System.Windows.Forms.ColumnHeader Отстъпка;
        private System.Windows.Forms.ColumnHeader Стойност;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

